string = '''Duster
E 200
E 200 2000
E 200 CGI
E 200 w210
E 220
E 220 211
E 220 CDI
E 220 ELEGANCE
E 220 W210...CDI
E 220 cdi
E 230
E 230 124
E 240
E 240 E 240
E 250
E 260
E 270
E 270 4
E 270 AVANGARDI
E 270 CDI
E 280
E 280 3.0
E 280 CDI
E 290
E 300
E 300 AVANTGARDE-LTD
E 320
E 320 4matic
E 320 4×4
E 320 bluetec
E 350
E 350 212
E 350 4 MATIC
E 350 4 Matic AMG Packag
E 350 4 matic
E 350 AMG
E 350 w211
E 350 ამგ
E 36 AMG
E 400
E 420
E 430
E 50
E 500
E 500 AMG
E 500 AVG
E 55
E 550
E-pace
E-pace p200
ES 300
ES 300 hybrid
ES 350
EX35
EX37
Eclipse
Eclipse ES
EcoSport
EcoSport SE
Edge
Edix
Edix FR-v
Elantra
Elantra 2014
Elantra 2016
Elantra GLS / LIMITED
Elantra GS
Elantra GT
Elantra Gt
Elantra LIMITED
Elantra LIMITEDI
Elantra Limited
Elantra SE
Elantra Se
Elantra gt
Elantra i30
Elantra limited
Elantra se
Elantra sport limited
Element
Elgrand
Elysion
Elysion 3.0
Enclave
Encore
Envoy
Eos
Equinox
Equinox LT
Escalade
Escape
Escape 3.0
Escape HYBRID
Escape Hybrid
Escape SE
Escape Titanium
Escape escape
Escape მერკური მერინერი
Escape სასწრაფოდ
Escort
Escudo
Estima
Eunos 500
Every Landy NISSAN SEREN
Expedition
Explorer
Explorer Turbo japan
Explorer XLT
F-pace
F-type
F-type R
F150
F50
FIT
FIT "S"- PAKETI.
FIT GP-5
FIT GP-6
FIT HIBRID
FIT HYBRYD
FIT Hbrid
FIT Hybrid
FIT LX
FIT Modulo
FIT NAVI PREMIUM
FIT PREMIUM PAKETI
FIT PREMIUMI
FIT Premiym
FIT RS
FIT RS MODELI
FIT RS MUGEN
FIT S
FIT SPORT
FIT Sport
FIT ex
FIT fit
FJ Cruiser
FX35
FX45
Fabia
Feroza
Fiesta
Fiesta 1.6
Fiesta SE
Fit Aria
Focus
Focus Flexfuel
Focus Fokusi
Focus SE
Focus SEL
Focus ST
Focus TITANIUM
Focus Titanium
Focus se
Forester
Forester 4x4
Forester CrossSport
Forester L.L.BEAN
Forester SH
Forester XT
Forester cross sport
Forester stb
Forte
Fortuner
Fred
Fred HIBRIDI
Freelander
Frontera
Frontera A B
Frontier
Fuga
Fun Cargo
Fusion
Fusion 1.6
Fusion 2015
Fusion Bybrid
Fusion HIBRID
Fusion HYBRID
Fusion HYBRID SE
Fusion Hybrid
Fusion SE
Fusion TITANIUM
Fusion Titanium
Fusion hybrid
Fusion phev
G 230 2.2cdi
G 300
G 320
G 350
G 55 AMG
G 550
G 63 AMG
G 65 AMG 63AMG
G 65 AMG G63 AMG
G20
G35 x
G37
G6
GL 320
GL 320 bluetec
GL 350
GL 350 BLUETEC
GL 350 BLUTEC
GL 350 Bluetec
GL 350 დიზელი
GL 450
GL 450 3.0
GL 500
GL 550
GL 63 AMG
GLA 200
GLA 250
GLC 250
GLC 300
GLC 300 GLC coupe
GLE 350
GLE 400
GLE 400 A M G
GLE 400 Coupe, AMG Kit
GLE 43 AMG
GLE 450
GLE 63 AMG
GLK 250
GLK 300
GLK 350
GLS 450
GLS 63 AMG
GONOW
GS 300
GS 350
GS 450
GTI
GX 460
GX 470
GX 470 470
GX 470 SUV 4D (4.7L V8 S
Galant
Galant GTS
Galaxy
Galloper
Genesis
Gentra
Getz
Ghibli
Giulietta
Gloria
Golf
Golf 1.8
Golf 2
Golf 3
Golf 4
Golf 6
Golf GOLF 5
Golf GTI
Golf Gti
Golf TDI
Grand Cherokee
Grand Cherokee LAREDO
Grand Cherokee Saiubileo
Grand Cherokee special e
Grand HIACE
Grand Vitara
Grandeur
Grandis
H1
H1 GRAND STAREX
H1 grandstarex
H1 starixs
H2
H3
H6
HHR
HS 250h
HS 250h Hybrid
HUSTLER
Harrier
Hiace
Highlander
Highlander 2,4
Highlander 2.4 lit
Highlander LIMITED
Highlander XLE
Highlander limited
Highlander sport
Hilux
Hilux Surf
Hr-v
Hr-v EX
Hr-v EXL
I
I30
INSIGNIA
IS 200
IS 250
IS 250 TURBO
IS 250 რესტაილინგი
IS 300
IS 350
IS 350 C
IS-F
ISIS
IVECO DAYLY
IX35
IX35 2.0
Ibiza
Ignis
Impala
Impreza
Impreza G4
Impreza Sport
Impreza WRX/STI LIMITED
Insight
Insight EX
Insight LX
Inspire
Integra
Intrepid
Ioniq
Ipsum
Ipsum S
Ist
Ist 1.5
JX35
Jetta
Jetta 1.4 TURBO
Jetta 2
Jetta 2.0
Jetta GLI
Jetta Hybrid
Jetta SE
Jetta SEL
Jetta SPORT
Jetta TDI
Jetta s
Jetta se
Jetta sei
Jetta sel
Jetta sport
Jetta სასწაფოდ
Jetta სპორტ
Jimny
Jimny GLX
Journey
Juke
Juke Juke
Juke NISMO
Juke Nismo
Juke Nismo RS
Juke Turbo
Juke juke
Juke nismo
KA
Kalos
Kangoo
Kangoo Waggon
Kicks
Kicks SR
Kizashi
Kizashi sporti
Korando
Kyron
L 200
LAFESTA
LATIO
LS 460
LX 470
LX 570
Lacetti
Laguna
Lancer
Lancer GT
Lancer GTS
Land Cruiser
Land Cruiser 100
Land Cruiser 105
Land Cruiser 11
Land Cruiser 200
Land Cruiser 80
Land Cruiser PRADO
Land Cruiser Prado
Land Cruiser Prado RX
Land Rover Sport
Lantra
Lantra LIMITED
Leaf
Legacy
Legacy B4
Legacy B4 twin turbo
Legacy Bl5
Legacy Outback
Legacy b4
Legacy bl5
Legend FULL
Leon
Liana
Liberty
Lupo
Lupo iaponuri
M3
M37
M4
M4 Competition
M5
M5 Japan
M5 Машина в максимально
M550
M6
M6 Gran cupe
MDX
MKZ
MKZ hybrid
ML 250
ML 270
ML 270 CDI
ML 280
ML 280 სასწრაფოდ
ML 300
ML 320
ML 320 AMG
ML 320 cdi
ML 350
ML 350 3.7
ML 350 370
ML 350 4 MATIC
ML 350 4matic
ML 350 BLUETEC
ML 350 ML350
ML 350 SPECIAL EDITION
ML 350 sport
ML 500
ML 500 AMG
ML 55 AMG
ML 550
ML 550 4.7
ML 63 AMG
MPV
MPV LX
Malibu
Malibu Hybrid
Malibu LT
Malibu eco
March
March 231212
March Rafeet
Mariner
Mariner Hybrid
Mark X
Mark X Zio
Matiz
Matrix XR
Maverick
Maxima
Mazda 2
Mazda 3
Mazda 3 SPORT
Mazda 5
Mazda 6
Mazda 6 Grand Touring
Mazda 6 Grand touring
Mazda 6 TOURING
Megane
Megane 1.5CDI
Megane 1.9 CDI
Megane 1.9CDI
Megane 19
Megane 5
Megane GT Line
Meriva
Micra
Micra <DIESEL>
Millenia
Minica
Mira
Mirage
Moco
Model X
Mondeo
Monterey
Montero
Montero Sport
Move
Mulsanne
Murano
Musa
Mustang
Mustang cabrio
Mustang ecoboost
Mx-5
NEW Beetle
NX 200
NX 300
Navara
Navigator
Neon
Niro
Niva
Noah
Note
Nubira
Octavia
Octavia SCOUT
Octavia Scout
Odyssey
Omega
Omega 1
Omega B
Omega b
Omega c
One
Optima
Optima ECO
Optima EX
Optima HYBRID
Optima Hybrid
Optima SXL
Optima X
Optima ex
Optima hybid
Optima hybrid
Optima k5
Orlando
Outback
Outback 2007
Outback 3.0
Outback Limited
Outlander
Outlander 2.0
Outlander SE
Outlander SPORT
Outlander Sport
Outlander sport
Outlander xl
Outlander სპორტ
PT Cruiser
PT Cruiser pt cruiser
Paceman
Pacifica
Pajero
Pajero 2.5diezel
Pajero IO
Pajero MONTERO
Pajero Mini
Pajero Mini 2008 წლიანი
Pajero Mini 2010 წლიანი
Pajero Sport
Panamera
Panamera 4
Panamera GTS
Panamera S
Panda
Passat
Passat 2.0 tfsi
Passat B5
Passat B7
Passat R-line
Passat RLAINI
Passat SE
Passat SEL
Passat Se
Passat pasat
Passat se
Passat sel
Passat sport
Passat tdi sel
Passat tsi-se
Passo
Passport
Pathfinder
Pathfinder SE
Patriot
Patriot 70th anniversary
Patriot Latitude
Patrol
Patrol Y60
Phaeton
Phantom
Picanto
Pilot
Polo
Polo GTI 16V
Premacy
Presage
Presage RIDER
Primera
Prius
Prius 1.5I
Prius 1.8
Prius 11
Prius 2014
Prius 3
Prius 9
Prius BLUG-IN
Prius C
Prius C 1.5I
Prius C 2013
Prius C 80 original
Prius C Hybrid
Prius C Navigation
Prius C YARIS IA
Prius C aqua
Prius C hybrid
Prius C ჰიბრიდი
Prius Plug IN
Prius Plug in
Prius S
Prius TSS LIMITED
Prius V
Prius V ALPINA
Prius V HIBRID
Prius V HYBRID
Prius personna
Prius plagin
Prius plug-in
Prius plugin
Prius prius
Prius s
Prius ფლაგინი
Prius ჰიბრიდი
Protege
Punto
Q3
Q45
Q5
Q5 Prestige
Q5 S-line
Q50 S Red
Q7
Q7 sport
QX56
QX60
QX80
Qashqai Advance CVT
Qashqai SPORT
Quattroporte
Quest
Quest 2016
R 320
R 350
R 350 BLUETEC
R2
RAM
RAM 1500
RAV 4
RAV 4 Dizel
RAV 4 L
RAV 4 LIMITED
RAV 4 Le
RAV 4 SPORT
RAV 4 SUPER!!!
RAV 4 XLE
RAV 4 XLE Sport
RAV 4 s p o r t
RAV 4 se
RC F
RC F F SPORT
RDX
REXTON
REXTON SUPER
RIO
RIO lX
RIO lx
RS6
RS7
RVR
RX 300
RX 350
RX 350 F sport
RX 400
RX 400 H
RX 400 HYBRID
RX 400 RESTAILING
RX 400 hybrid
RX 450
RX 450 F SPORT
RX 450 H
RX 450 HYBRID
Ractis
Ramcharger
Range Rover
Range Rover Evoque
Range Rover Evoque 2.0
Range Rover Evoque რესტა
Range Rover VOGUE
Range Rover Velar
Range Rover Vogue
Ranger
Ranger Wildtrak
Rasheen
Regal
Renegade
Ridgeline
Rodeo
Rogue
Rogue SL
Rogue SPORT
Rogue Sport
Routan SEL
Rx-8
S 320
S 350
S 350 CDI 320
S 350 Longia
S 350 W2222
S 400
S 420
S 430
S 430 4.3
S 500
S 500 67
S 500 long
S 55 5.5
S 550
S 550 LONG
S 550 ჰიბრიდი
S 600
S 63 AMG
S-max
S-type
S3
S40
S6
S60
S70
S80
SJ 413 Samurai
SL 55 AMG
SLK 230
SLK 32 AMG
SLK 350 300
SOUL
SRX
SX4
Sai
Sambar
Samurai
Santa FE
Santa FE Ultimate
Santa FE long
Santa FE sport
Scenic
Scirocco
Scorpio
Sebring
Seicento fiat 600
Sentra
Sequoia
Serena
Serena Serea
Sharan
Shuttle
Sienna
Sienta
Sienta LE
Sierra
Sierra DIZEL
Silverado
Silvia
Sintra
Sirion
Skyline
Skyline 4WD
Skyline GT250
Smart
Smart Fortwo
Sonata
Sonata 2.0t
Sonata 2.4L
Sonata HYBRID
Sonata Hibrid
Sonata Hybrid
Sonata LIMITED
Sonata LPG
Sonata Limited
Sonata S
Sonata SE
Sonata SE LIMITED
Sonata SPORT
Sonata Sport
Sonata blue edition
Sonata hybrid
Sonata sport
Sonata სასწრაფოდ
Sonic
Sonic LT
Sorento
Sorento EX
Sorento SX
Space Runner
Spark
Sportage
Sportage EX
Sportage PRESTIGE
Sportage SX
Sprinter
Sprinter 308 CDI
Sprinter 311
Sprinter 313
Sprinter 313CDI
Sprinter 314
Sprinter 315CDI
Sprinter 315CDI-XL
Sprinter 316
Sprinter 316 CDI
Sprinter 411
Sprinter 516
Sprinter EURO4
Sprinter MAX
Sprinter Maxi-ს Max
Sprinter VAN
Sprinter VIP CLASS
Sprinter სატვირთო
Stella
Step Wagon
Step Wagon Pada
Step Wagon RG2 SPADA
Stream
Suburban
Superb
Swift
Swift Sport
T3
T3 0000
T5
TERRAIN
TL
TL saber
TLX
TSX
TT
Tacoma
Tacoma TRD Off Road
Taurus
Taurus X
Taurus interceptor
Teana
Terios
Terrano
Tigra
Tiguan
Tiguan SE
Tiida
Tiida 15 M
Tiida 2008
Tiida AXIS
Tiida Latio
Touareg
Touran
Tourneo Connect
Town Car
Town and Country
Trailblazer
Transit
Transit 100LD
Transit 135
Transit 2.4
Transit 350T
Transit CL
Transit Connect
Transit Connect Prastoi
Transit Connect ბენზინი
Transit Custom
Transit Fff
Transit S
Transit T330
Transit Tourneo
Transit ford
Transit პერეგაროტკა
Transporter
Traverse
Trax
Tribute
Tribute სასწრაფოდ
Tucson
Tucson Limited
Tucson SE
Tucson Se
Tucson TURBO
Tundra
Twingo
UP
Urus
V 230
V50
VOXY
VOXY 2003
Vaneo
Vanette
Vectra
Vectra 1.6
Vectra B
Vectra C
Vectra H
Vectra b
Vectra c
Vectra ბ
VehiCross
Veloster
Veloster R-spec
Veloster TURBO
Veloster Turbo
Veloster remix
Vento
Venza
Veracruz
Verisa
Verisa 2007
Versa
Versa SE
Versa s
Verso
Vesta
Viano
Viano Ambiente
Virage
Vitara
Vitara GL+
Vito
Vito 110d
Vito 111
Vito 111 CDI
Vito 113
Vito 115
Vito 115 CDI
Vito 2.2
Vito Exstralong
Vito Extra Long
Vito Extralong
Vito long115
Vitz
Vitz RS
Vitz funkargo
Vitz i.ll
Volt
Volt Full Packet
Volt PREMIER
Volt Premier
Volt premier
Vue
Will Chypa
Will Vs
Wingroad
Wish
Wizard
Wrangler
Wrangler ARB
Wrangler sport
X 250
X 250 ევროპული
X-Terra
X-Trail
X-Trail NISMO
X-Trail NISSAN X TRAIL R
X-Trail X-trail
X-Trail gt
X-type
X1
X1 28Xdrive
X1 4X4
X1 X-Drive
X3
X3 3.5i
X3 SDRIVE
X4
X5
X5 3.0
X5 3.0i
X5 3.5
X5 35d
X5 4,4i
X5 4.8is
X5 DIESEL
X5 E70
X5 Japan
X5 M
X5 M packet
X5 Sport
X5 X-Drive
X5 XDRIVE
X5 XDRIVE 35D
X5 e53
X5 rest
X5 restilling
X5 x5
X6
X6 40D
X6 GERMANY
X6 Limited
X6 M
XC90
XC90 2.5turbo
XC90 3.2 AWD
XE
XF
XJ
XK
XL7
XL7 limited
XV
XV HYBRID
XV LIMITED
YRV
Yaris
Yaris IA
Yaris RS
Yaris SE
Yaris iA
Yukon
Z4
Z4 3,0 SI
Zafira
Zafira B
i20
i3
i40
iA isti
kona
macan
macan S
tC
xD'''

def convert_to_list(raw_data):
    # Split the raw data by new lines to create a list
        model_list = raw_data.split("\n")
        return model_list

print(convert_to_list(string))