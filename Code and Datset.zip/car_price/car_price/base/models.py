from django.db import models
from django.contrib.auth.models import User

class History(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    manufacturer = models.CharField(max_length=255,default='Nil')
    model = models.CharField(max_length=255,default='Nil')
    prod_year = models.PositiveIntegerField(default=0)
    fuel_type = models.CharField(max_length=255,default='Nil')
    mileage = models.PositiveIntegerField(default=0)
    color = models.CharField(max_length=255,default='Nil')
    price = models.IntegerField(default=0)

    def __str__(self):
        return self.user.username