import joblib

manufacturer_encoder = joblib.load(r'models\Manufacturer_encoder.pkl')
fuel_type = joblib.load(r'models\Fuel_Type_encoder.pkl')
color_encoder = joblib.load(r'models\Color_encoder.pkl')
model_encoder = joblib.load(r'models\Model_encoder.pkl')

LABEL_ENCODER = {
    'Manufacturer' : manufacturer_encoder,
    'Fuel_Type' : fuel_type,
    'Color' : color_encoder,
    'Model' : model_encoder
}


