from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required


from .variables import MODEL_TYPE, MANUFACTURER_LIST, FUEL_TYPE, COLOR
from .utils import predict_price_model
from .models import History


def home(request):
    context = {}
    if request.user.is_authenticated:
        curr_user = request.user
        history_ins = History.objects.filter(user=curr_user)
        context['history_ins'] = history_ins
    
    context['model_type'] = MODEL_TYPE
    context['manufacturers'] = MANUFACTURER_LIST
    context['fuel_types'] = FUEL_TYPE
    context['colors'] = COLOR
    
    

    return render(request, 'home.html', context)


def user_register(request):
    context ={}
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        user = User.objects.create_user(username=username, password=password, email=email)
        login(request, user)
        return redirect('home')
    return render(request, 'register.html', context)

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
    return render(request, 'login.html')

def user_logout(request):
    logout(request)
    return redirect('home')

@login_required
def predict_price(request):
    curr_user = request.user
    if request.method == 'POST':
        manufacturer = request.POST['manufacturer']
        model = request.POST['model']
        prod_year = request.POST['prod_year']
        fuel_type = request.POST['fuel_type']
        mileage = request.POST['mileage']
        color = request.POST['color']

        price = predict_price_model(manufacturer, model, int(prod_year), fuel_type, int(mileage), color)
        history_ins = History.objects.create(user=curr_user, manufacturer=manufacturer, model=model, prod_year=prod_year, fuel_type=fuel_type, mileage=mileage, color=color, price=price)
        print(price)
        return redirect(request.META.get('HTTP_REFERER', '/'))
    return HttpResponse("<p>Submit form from home page</p>")