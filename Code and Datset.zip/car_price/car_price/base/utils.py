import tensorflow as tf
from tensorflow.keras.models import load_model
import joblib
import pandas as pd

from .encoders import LABEL_ENCODER
model = load_model(r'models\car_price_model.h5')
scaler = joblib.load(r'models\scaler.pkl')

print(scaler.n_features_in_)

def predict_price_model(manufacturer, model_name, prod_year, fuel_type, mileage, color):
    inputs = pd.DataFrame([[manufacturer, model_name, prod_year, fuel_type, mileage, color]],
                              columns=['Manufacturer', 'Model', 'Prod_Year', 'Fuel_Type', 'Mileage', 'Color'])

        # Apply label encoding
    for feature in ['Manufacturer', 'Model', 'Fuel_Type', 'Color']:
        inputs[feature] = LABEL_ENCODER[feature].transform(inputs[feature])

        # Apply scaling
    inputs[['Prod_Year', 'Mileage']] = scaler.transform(inputs[['Prod_Year', 'Mileage']])
    prediction = model.predict(inputs)
    x=prediction[0][0]*83.38
    return x
